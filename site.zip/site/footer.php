
    <footer>

        <div class="row mt-3">
            <!--<div class="col-12 col-sm-12">

                <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                    <a class="text-white" href="#">
                        <p class="pr-3">mentions légales</p>
                    </a>
                    <a class="text-white" href="#">
                        <p class="pr-3">horaires</p>
                    </a>
                    <a class="text-white" href="#">
                        <p class="pr-3">plan du site</p>
                    </a>
                </nav>

            </div>-->
            
            <div class="col-12 col-sm-12">
                <div class="text-center">
                    <img src="img/FOOTER/footer SIMPLE.png" class="img-fluid" alt="Footer" title="Footer">
                </div>
            </div>
        </div>

    </footer>

    </div> <!-- fermerure de la div class="container" ouverte dans le header -->

</body>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
</script>

</html>