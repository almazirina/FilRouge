<?php
include("header.php");
?>

<div class="row m-0">
    <div class="col-12 col-sm-12">
        <div class="text-center">
            <img src="img/BODY/pub guitare.png" class="w-100" alt="-15% sur les guitares" title="Promotions guitares">
        </div>
    </div>
</div>

<?php
include("footer.php");
?>